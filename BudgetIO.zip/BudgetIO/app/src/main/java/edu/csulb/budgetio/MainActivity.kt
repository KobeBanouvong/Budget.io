package edu.csulb.budgetio

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var incomeInput: EditText
    private lateinit var calculateButton: Button
    private lateinit var pieChartView: PieChartView
    private lateinit var needsButton: Button
    private lateinit var wantsButton: Button
    private lateinit var savingsButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        incomeInput = findViewById(R.id.incomeInput)
        calculateButton = findViewById(R.id.calculateButton)
        pieChartView = findViewById(R.id.pieChartView)
        needsButton = findViewById(R.id.needsButton)
        wantsButton = findViewById(R.id.wantsButton)
        savingsButton = findViewById(R.id.savingsButton)

        calculateButton.setOnClickListener {
            val incomeText = incomeInput.text.toString()
            if (incomeText.isNotEmpty()) {
                val income = incomeText.toDouble()
                val needs = income * 0.5
                val wants = income * 0.3
                val savings = income * 0.2
                pieChartView.setData(needs, wants, savings)
            }
        }

        needsButton.setOnClickListener {
            val intent = Intent(this, NeedsActivity::class.java)
            startActivity(intent)
        }

        wantsButton.setOnClickListener {
            val intent = Intent(this, WantsActivity::class.java)
            startActivity(intent)
        }

        savingsButton.setOnClickListener {
            val intent = Intent(this, SavingsActivity::class.java)
            startActivity(intent)
        }
    }
}
