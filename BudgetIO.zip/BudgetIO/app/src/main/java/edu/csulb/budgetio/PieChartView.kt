package edu.csulb.budgetio

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class PieChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint()
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private var needsAmount: Float = 0f
    private var wantsAmount: Float = 0f
    private var savingsAmount: Float = 0f
    private var animatedValue: Float = 0f

    init {
        textPaint.color = Color.WHITE
        textPaint.textSize = 29f
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    fun setData(needs: Double, wants: Double, savings: Double) {
        needsAmount = needs.toFloat()
        wantsAmount = wants.toFloat()
        savingsAmount = savings.toFloat()
        startAnimation()
    }

    private fun startAnimation() {
        val animator = ValueAnimator.ofFloat(0f, 1f)
        animator.duration = 1000
        animator.addUpdateListener { animation ->
            animatedValue = animation.animatedValue as Float
            invalidate()
        }
        animator.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val total = needsAmount + wantsAmount + savingsAmount
        if (total == 0f) return

        val centerX = width / 2f
        val centerY = height / 2f
        val radius = Math.min(width, height) / 2f * 0.8f
        val textRadius = radius * 1.2f

        var startAngle = 0f


        val needsSweep = (needsAmount / total * 360) * animatedValue
        drawSegment(canvas, centerX, centerY, radius, startAngle, needsSweep, Color.parseColor("#CF6679"))
        drawLabel(canvas, "Needs: $${String.format("%.2f", needsAmount)}", startAngle + needsSweep / 2, centerX, centerY, textRadius)
        startAngle += needsSweep


        val wantsSweep = (wantsAmount / total * 360) * animatedValue
        drawSegment(canvas, centerX, centerY, radius, startAngle, wantsSweep, Color.parseColor("#4682B4"))
        drawLabel(canvas, "Wants: $${String.format("%.2f", wantsAmount)}", startAngle + wantsSweep / 2, centerX, centerY, textRadius)
        startAngle += wantsSweep


        val savingsSweep = (savingsAmount / total * 360) * animatedValue
        drawSegment(canvas, centerX, centerY, radius, startAngle, savingsSweep, Color.parseColor("#3CB371"))
        drawLabel(canvas, "Savings: $${String.format("%.2f", savingsAmount)}", startAngle + savingsSweep / 2, centerX, centerY, textRadius)
    }

    private fun drawSegment(canvas: Canvas, centerX: Float, centerY: Float, radius: Float, startAngle: Float, sweepAngle: Float, color: Int) {
        paint.color = color
        paint.style = Paint.Style.FILL
        path.reset()
        path.moveTo(centerX, centerY)
        path.arcTo(centerX - radius, centerY - radius, centerX + radius, centerY + radius, startAngle, sweepAngle, true)
        path.lineTo(centerX, centerY)
        path.close()
        canvas.drawPath(path, paint)
    }

    private fun drawLabel(canvas: Canvas, label: String, angle: Float, centerX: Float, centerY: Float, textRadius: Float) {
        val radianAngle = Math.toRadians(angle.toDouble())
        val x = centerX + textRadius * Math.cos(radianAngle).toFloat()
        val y = centerY + textRadius * Math.sin(radianAngle).toFloat()
        canvas.drawText(label, x, y, textPaint)
    }
}
